"""
Alarm code to human-readable description mapping
Maps technical alarm codes to user-friendly messages with severity and actions
"""

ALARM_DESCRIPTIONS = {
    # pH Controller Alarms
    "Status_Mode_Controller2_pH:b0": {
        "name": "pH Controller in Manual Mode",
        "severity": "warning",
        "description": "pH dosing controller is set to manual mode - automatic dosing disabled",
        "action": "Check if manual control is intended. Switch to auto mode if needed.",
    },
    "Status_Mode_Controller2_pH:b1": {
        "name": "pH Controller Error",
        "severity": "critical",
        "description": "pH controller has detected an error condition",
        "action": "Check pH probe connection and calibration. Review controller display.",
    },
    "Status_Mode_Controller2_pH:b2": {
        "name": "pH Probe Fault",
        "severity": "critical",
        "description": "pH probe is not responding or giving invalid readings",
        "action": "Clean or replace pH probe. Check wiring connections.",
    },
    "Status_Mode_Controller2_pH:b3": {
        "name": "pH Dosing Pump Fault",
        "severity": "critical",
        "description": "pH dosing pump has stopped or is not operating correctly",
        "action": "Check pump operation, tubing, and chemical supply.",
    },

    # Chlorine Controller Alarms
    "Status_Mode_Controller1_Chlorine:b0": {
        "name": "Chlorine Controller in Manual Mode",
        "severity": "warning",
        "description": "Chlorine dosing controller is set to manual mode - automatic dosing disabled",
        "action": "Check if manual control is intended. Switch to auto mode if needed.",
    },
    "Status_Mode_Controller1_Chlorine:b1": {
        "name": "Chlorine Controller Error",
        "severity": "critical",
        "description": "Chlorine controller has detected an error condition",
        "action": "Check chlorine probe connection and calibration. Review controller display.",
    },
    "Status_Mode_Controller1_Chlorine:b2": {
        "name": "Chlorine Probe Fault",
        "severity": "critical",
        "description": "Chlorine probe is not responding or giving invalid readings",
        "action": "Clean or replace chlorine probe. Check wiring connections.",
    },
    "Status_Mode_Controller1_Chlorine:b3": {
        "name": "Chlorine Dosing Pump Fault",
        "severity": "critical",
        "description": "Chlorine dosing pump has stopped or is not operating correctly",
        "action": "Check pump operation, tubing, and chemical supply.",
    },
    "Status_Mode_Controller1_Chlorine:b4": {
        "name": "Low Chlorine Chemical",
        "severity": "warning",
        "description": "Chlorine chemical level is low",
        "action": "Refill chlorine chemical tank.",
    },

    # ORP Controller Alarms
    "Status_Mode_Controller3_ORP:b0": {
        "name": "ORP Controller in Manual Mode",
        "severity": "warning",
        "description": "ORP controller is set to manual mode",
        "action": "Check if manual control is intended. Switch to auto mode if needed.",
    },
    "Status_Mode_Controller3_ORP:b2": {
        "name": "ORP Probe Fault",
        "severity": "critical",
        "description": "ORP (Redox) probe is not responding or giving invalid readings",
        "action": "Clean or replace ORP probe. Check wiring connections.",
    },

    # Relay/Output Alarms
    "Status_RelayOutputs_K1_8:b0": {
        "name": "Relay K1 Activated",
        "severity": "info",
        "description": "Output relay K1 is active (pump or valve operation)",
        "action": "Normal operation - no action needed.",
    },
    "Status_RelayOutputs_K1_8:b1": {
        "name": "Relay K2 Activated",
        "severity": "info",
        "description": "Output relay K2 is active (pump or valve operation)",
        "action": "Normal operation - no action needed.",
    },
    "Status_RelayOutputs_K1_8:b2": {
        "name": "Relay K3 Activated",
        "severity": "info",
        "description": "Output relay K3 is active (pump or valve operation)",
        "action": "Normal operation - no action needed.",
    },
    "Status_RelayOutputs_K1_8:b3": {
        "name": "Relay K4 Activated",
        "severity": "info",
        "description": "Output relay K4 is active (pump or valve operation)",
        "action": "Normal operation - no action needed.",
    },

    # Limit/Contact Alarms
    "Status_LimitContactStates:b0": {
        "name": "Limit Contact 1 Triggered",
        "severity": "warning",
        "description": "External limit contact or interlock has been triggered",
        "action": "Check connected equipment and safety interlocks.",
    },
    "Status_LimitContactStates:b1": {
        "name": "Flow Switch Open",
        "severity": "critical",
        "description": "No water flow detected - pump may not be running",
        "action": "Check pump operation and flow switch. Dosing stopped for safety.",
    },
    "Status_LimitContactStates:b2": {
        "name": "High Level Alarm",
        "severity": "critical",
        "description": "Chemical tank high level alarm activated",
        "action": "Check chemical tank levels and sensors.",
    },
    "Status_LimitContactStates:b3": {
        "name": "Low Level Alarm",
        "severity": "warning",
        "description": "Chemical tank low level alarm activated",
        "action": "Refill chemical tank.",
    },

    # System Alarms
    "Status_SystemAlarm:b0": {
        "name": "General System Alarm",
        "severity": "critical",
        "description": "Controller has detected a system fault",
        "action": "Check controller display for specific error code.",
    },
    "Status_SystemAlarm:b1": {
        "name": "Communication Error",
        "severity": "critical",
        "description": "Communication lost with controller or peripheral",
        "action": "Check network connections and Modbus communication.",
    },
    "Status_SystemAlarm:b2": {
        "name": "Power Fault",
        "severity": "critical",
        "description": "Power supply issue detected",
        "action": "Check power supply voltage and connections.",
    },
}


SEVERITY_COLORS = {
    "info": "#0b5bd3",      # Blue
    "warning": "#ff9800",   # Orange
    "critical": "#b00020",  # Red
}


SEVERITY_ICONS = {
    "info": "ℹ️",
    "warning": "⚠️",
    "critical": "🚨",
}


def get_alarm_info(label):
    """
    Get human-readable alarm information

    Args:
        label: Technical alarm label (e.g., "Status_Mode_Controller2_pH:b0")

    Returns:
        dict with name, severity, description, action, color, icon
    """
    if label in ALARM_DESCRIPTIONS:
        info = ALARM_DESCRIPTIONS[label].copy()
        severity = info.get("severity", "info")
        info["color"] = SEVERITY_COLORS.get(severity, "#888")
        info["icon"] = SEVERITY_ICONS.get(severity, "•")
        return info

    # Fallback for unknown alarms
    return {
        "name": label,  # Use technical name
        "severity": "info",
        "description": "Status change detected",
        "action": "Monitor system behavior.",
        "color": "#888",
        "icon": "•",
    }


def clean_system_name(raw_name):
    """Clean up system name by removing null characters and extra data"""
    if not raw_name:
        return ""

    # Remove null characters and split by common delimiters
    cleaned = raw_name.replace('\x00', ' ').strip()

    # Often the format is: "Pool name <nulls> version <nulls> date"
    # Take only the first meaningful part
    parts = [p.strip() for p in cleaned.split() if p.strip()]
    if parts:
        # Return first non-version part (version usually starts with 'v')
        for part in parts:
            if not part.startswith('v') and not part.replace('.', '').replace('-', '').isdigit():
                return part
        return parts[0]

    return cleaned
