# Copyright Ben Salmon 2026. All Rights Reserved.
# PoolAIssistant - Health Check Endpoint

"""
Health check endpoint for monitoring Pi status.
Server can ping this to verify the Pi is alive and functioning.
"""

import os
import sqlite3
from datetime import datetime
from pathlib import Path
from flask import Blueprint, jsonify, current_app

health_bp = Blueprint("health", __name__)

DATA_DIR = Path("/opt/PoolAIssistant/data")
APP_DIR = Path("/opt/PoolAIssistant/app")


def get_disk_usage():
    """Get disk usage percentage."""
    try:
        stat = os.statvfs("/")
        total = stat.f_blocks * stat.f_frsize
        free = stat.f_bavail * stat.f_frsize
        used_pct = round((1 - free / total) * 100, 1)
        return {"total_gb": round(total / 1e9, 2), "free_gb": round(free / 1e9, 2), "used_pct": used_pct}
    except:
        return None


def get_db_stats():
    """Get database statistics."""
    try:
        db_path = DATA_DIR / "pool_readings.sqlite3"
        if not db_path.exists():
            return None

        size_mb = round(db_path.stat().st_size / 1e6, 2)

        conn = sqlite3.connect(str(db_path), timeout=5)
        cursor = conn.cursor()
        cursor.execute("SELECT COUNT(*) FROM readings")
        row_count = cursor.fetchone()[0]
        cursor.execute("SELECT MAX(ts) FROM readings")
        last_reading = cursor.fetchone()[0]
        conn.close()

        return {"size_mb": size_mb, "row_count": row_count, "last_reading": last_reading}
    except:
        return None


def get_version():
    """Get current software version."""
    version_file = APP_DIR / "VERSION"
    if version_file.exists():
        return version_file.read_text().strip()
    return os.environ.get("SOFTWARE_VERSION", "unknown")


def get_uptime():
    """Get system uptime."""
    try:
        with open("/proc/uptime") as f:
            uptime_seconds = float(f.read().split()[0])
            days = int(uptime_seconds // 86400)
            hours = int((uptime_seconds % 86400) // 3600)
            minutes = int((uptime_seconds % 3600) // 60)
            return {"seconds": int(uptime_seconds), "human": f"{days}d {hours}h {minutes}m"}
    except:
        return None


def check_services():
    """Check if critical services are running."""
    import subprocess
    services = {}
    for svc in ["poolaissistant_ui", "poolaissistant_logger"]:
        try:
            result = subprocess.run(
                ["systemctl", "is-active", svc],
                capture_output=True, text=True, timeout=5
            )
            services[svc] = result.stdout.strip() == "active"
        except:
            services[svc] = False
    return services


@health_bp.route("/api/health")
def health_check():
    """
    Health check endpoint.
    Returns system status for monitoring.
    """
    disk = get_disk_usage()
    db = get_db_stats()
    services = check_services()

    # Determine overall health
    healthy = True
    issues = []

    if disk and disk["used_pct"] > 90:
        healthy = False
        issues.append("Disk usage critical (>90%)")

    if not all(services.values()):
        healthy = False
        issues.append("Some services not running")

    return jsonify({
        "ok": healthy,
        "timestamp": datetime.utcnow().isoformat() + "Z",
        "version": get_version(),
        "uptime": get_uptime(),
        "disk": disk,
        "database": db,
        "services": services,
        "issues": issues
    })


@health_bp.route("/api/ping")
def ping():
    """Simple ping endpoint - minimal response for quick checks."""
    return jsonify({"ok": True, "ts": datetime.utcnow().isoformat() + "Z"})
