#!/bin/bash
# set_screen_rotation.sh - Rotate display and touchscreen on Raspberry Pi
# Usage: sudo ./set_screen_rotation.sh <degrees>
# Where degrees is 0, 90, 180, or 270

set -e

ROTATION="${1:-0}"

# Validate rotation value
if [[ ! "$ROTATION" =~ ^(0|90|180|270)$ ]]; then
    echo "Error: Rotation must be 0, 90, 180, or 270"
    exit 1
fi

# Map rotation degrees to config.txt display_lcd_rotate value
# 0=normal, 1=90°, 2=180°, 3=270°
case "$ROTATION" in
    0)   LCD_ROTATE=0 ;;
    90)  LCD_ROTATE=1 ;;
    180) LCD_ROTATE=2 ;;
    270) LCD_ROTATE=3 ;;
esac

# Determine which config file to use (modern vs legacy Pi OS)
if [ -f /boot/firmware/config.txt ]; then
    CONFIG_FILE="/boot/firmware/config.txt"
elif [ -f /boot/config.txt ]; then
    CONFIG_FILE="/boot/config.txt"
else
    echo "Error: Could not find config.txt"
    exit 1
fi

echo "Setting screen rotation to ${ROTATION}° (lcd_rotate=${LCD_ROTATE})"
echo "Config file: ${CONFIG_FILE}"

# Backup config file
cp "$CONFIG_FILE" "${CONFIG_FILE}.bak.$(date +%Y%m%d_%H%M%S)"

# Remove existing rotation settings
sed -i '/^display_lcd_rotate=/d' "$CONFIG_FILE"
sed -i '/^lcd_rotate=/d' "$CONFIG_FILE"
sed -i '/^display_rotate=/d' "$CONFIG_FILE"
sed -i '/^dtoverlay=vc4-kms-v3d,rotation=/d' "$CONFIG_FILE"

# Add the rotation setting
# For official Raspberry Pi touchscreen on Pi 5
if grep -q "dtoverlay=vc4-kms-v3d" "$CONFIG_FILE"; then
    # Modern KMS driver - use display_lcd_rotate
    echo "display_lcd_rotate=${LCD_ROTATE}" >> "$CONFIG_FILE"
else
    # Legacy or other setups
    echo "lcd_rotate=${LCD_ROTATE}" >> "$CONFIG_FILE"
fi

echo "Config file updated."

# Try to apply rotation immediately using wlr-randr (Wayland) or xrandr (X11)
# This allows immediate feedback without reboot

# Find the logged-in user running the display
DISPLAY_USER=$(who | grep -E 'tty|:0' | head -1 | awk '{print $1}' || echo "pi")
if [ -z "$DISPLAY_USER" ]; then
    DISPLAY_USER="pi"
fi

# Get the user's runtime directory for Wayland
XDG_RUNTIME_DIR="/run/user/$(id -u "$DISPLAY_USER" 2>/dev/null || echo 1000)"

echo "Display user: $DISPLAY_USER"
echo "XDG_RUNTIME_DIR: $XDG_RUNTIME_DIR"

# Check for Wayland (labwc/wlroots on newer Pi OS)
if command -v wlr-randr &> /dev/null && [ -S "$XDG_RUNTIME_DIR/wayland-0" ]; then
    echo "Attempting Wayland rotation with wlr-randr..."
    case "$ROTATION" in
        0)   TRANSFORM="normal" ;;
        90)  TRANSFORM="90" ;;
        180) TRANSFORM="180" ;;
        270) TRANSFORM="270" ;;
    esac
    # Try to rotate the first connected output
    OUTPUT=$(sudo -u "$DISPLAY_USER" XDG_RUNTIME_DIR="$XDG_RUNTIME_DIR" WAYLAND_DISPLAY=wayland-0 wlr-randr 2>/dev/null | grep -m1 "^[A-Z]" | awk '{print $1}' || true)
    if [ -n "$OUTPUT" ]; then
        sudo -u "$DISPLAY_USER" XDG_RUNTIME_DIR="$XDG_RUNTIME_DIR" WAYLAND_DISPLAY=wayland-0 wlr-randr --output "$OUTPUT" --transform "$TRANSFORM" 2>/dev/null && echo "Applied Wayland rotation to $OUTPUT" || echo "Wayland rotation failed"
    else
        echo "No Wayland output found"
    fi
# Check for X11
elif command -v xrandr &> /dev/null; then
    echo "Attempting X11 rotation with xrandr..."
    case "$ROTATION" in
        0)   XROTATE="normal" ;;
        90)  XROTATE="right" ;;
        180) XROTATE="inverted" ;;
        270) XROTATE="left" ;;
    esac
    # Get primary output
    OUTPUT=$(sudo -u "$DISPLAY_USER" DISPLAY=:0 xrandr 2>/dev/null | grep " connected" | head -1 | awk '{print $1}' || true)
    if [ -n "$OUTPUT" ]; then
        sudo -u "$DISPLAY_USER" DISPLAY=:0 XAUTHORITY="/home/$DISPLAY_USER/.Xauthority" xrandr --output "$OUTPUT" --rotate "$XROTATE" 2>/dev/null && echo "Applied X11 rotation to $OUTPUT" || echo "X11 rotation failed"
    else
        echo "No X11 output found"
    fi
else
    echo "No display rotation tool available (wlr-randr or xrandr)"
fi

# Update touchscreen calibration for libinput (needed for touch to match display)
# This maps rotation to a transformation matrix
echo "Configuring touchscreen input rotation..."

case "$ROTATION" in
    0)   MATRIX="1 0 0 0 1 0" ;;       # Identity matrix
    90)  MATRIX="0 1 0 -1 0 1" ;;      # 90° clockwise
    180) MATRIX="-1 0 1 0 -1 1" ;;     # 180°
    270) MATRIX="0 -1 1 1 0 0" ;;      # 270° (90° counter-clockwise)
esac

# Create/update libinput quirks for touchscreen rotation
QUIRKS_DIR="/etc/libinput"
QUIRKS_FILE="${QUIRKS_DIR}/local-overrides.quirks"

mkdir -p "$QUIRKS_DIR"

# Try to find the touchscreen device
TOUCH_DEVICE=$(grep -l -r "touchscreen\|FT5406\|Goodix\|eGalax\|ELAN\|ADS7846" /sys/class/input/*/name 2>/dev/null | head -1 || true)
if [ -n "$TOUCH_DEVICE" ]; then
    TOUCH_NAME=$(cat "$TOUCH_DEVICE" 2>/dev/null || echo "")
    echo "Found touchscreen: $TOUCH_NAME"
fi

# Write calibration to Xorg config (for X11)
XORG_CONF="/etc/X11/xorg.conf.d/99-touchscreen-rotation.conf"
mkdir -p /etc/X11/xorg.conf.d
cat > "$XORG_CONF" << EOF
Section "InputClass"
    Identifier "Touchscreen rotation"
    MatchIsTouchscreen "on"
    Option "CalibrationMatrix" "${MATRIX} 0 0 1"
EndSection
EOF

echo "Touchscreen calibration configured."
echo ""
echo "=== ROTATION COMPLETE ==="
echo "Display rotation: ${ROTATION}°"
echo "A REBOOT is recommended for full touchscreen calibration to take effect."
echo "Run: sudo reboot"
