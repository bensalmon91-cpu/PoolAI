#!/usr/bin/env python3
"""
Auto-Provisioning Script for PoolAIssistant

Automatically registers the Pi with the MOD Projects server on first boot.
Uses a bootstrap secret to authenticate and receives an API key in return.

This script should run on boot before the main UI starts.
If already provisioned (API key exists), it exits immediately.

Usage:
    python auto_provision.py          # Normal provisioning
    python auto_provision.py --force  # Force re-provisioning
"""

import argparse
import json
import os
import sys
import time
from pathlib import Path

import requests

# Paths
SCRIPT_DIR = Path(__file__).resolve().parent
PROJECT_DIR = SCRIPT_DIR.parent
INSTANCE_DIR = PROJECT_DIR / "instance"
DATA_DIR = Path(os.environ.get("POOLDASH_DATA_DIR", "/opt/PoolAIssistant/data"))

# Settings path
SETTINGS_PATH = Path(os.environ.get("POOLDASH_SETTINGS_PATH", DATA_DIR / "pooldash_settings.json"))

# Retry settings
MAX_RETRIES = 5
RETRY_DELAY = 10  # seconds

# Add project dir to path to import persist
sys.path.insert(0, str(PROJECT_DIR / "pooldash_app"))
try:
    import persist as persist_module
    USE_PERSIST = True
except ImportError:
    USE_PERSIST = False


def load_settings():
    """Load settings using persist module (includes hardcoded defaults)."""
    if USE_PERSIST:
        # Use persist.load() which has hardcoded backend_url and bootstrap_secret
        return persist_module.load(str(DATA_DIR))
    # Fallback to direct file read
    if not SETTINGS_PATH.exists():
        return {}
    try:
        with open(SETTINGS_PATH, "r", encoding="utf-8") as f:
            return json.load(f)
    except Exception as e:
        print(f"Error loading settings: {e}")
        return {}


def save_settings(settings):
    """Save settings using persist module."""
    try:
        if USE_PERSIST:
            persist_module.save(str(DATA_DIR), settings)
            print(f"Settings saved to {SETTINGS_PATH}")
            return True
        # Fallback to direct file write
        SETTINGS_PATH.parent.mkdir(parents=True, exist_ok=True)
        with open(SETTINGS_PATH, "w", encoding="utf-8") as f:
            json.dump(settings, f, indent=2, sort_keys=True)
        print(f"Settings saved to {SETTINGS_PATH}")
        return True
    except Exception as e:
        print(f"Error saving settings: {e}")
        return False


def get_or_create_device_id(settings):
    """Get existing device ID or create a new one."""
    device_id = settings.get("device_id", "")
    if not device_id:
        import uuid
        device_id = str(uuid.uuid4())
        settings["device_id"] = device_id
        save_settings(settings)
        print(f"Generated new device ID: {device_id}")
    return device_id


def provision(settings, force=False):
    """Attempt to provision the device with the server."""

    # Check if already provisioned
    api_key = settings.get("remote_api_key", "")
    if api_key and not force:
        print(f"Already provisioned (API key exists: {api_key[:8]}...)")
        return True

    # Check for required settings
    # Prefer backend_url, fall back to remote_sync_url
    backend_url = settings.get("backend_url", "").strip()
    if not backend_url:
        backend_url = settings.get("remote_sync_url", "").strip()
    bootstrap_secret = settings.get("bootstrap_secret", "").strip()

    if not backend_url:
        print("No backend_url or remote_sync_url configured - skipping provisioning")
        print("Set 'backend_url' in settings to enable auto-provisioning")
        return False

    if not bootstrap_secret:
        print("No bootstrap_secret configured - skipping provisioning")
        print("Set 'bootstrap_secret' in settings to enable auto-provisioning")
        return False

    # Get device info
    device_id = get_or_create_device_id(settings)
    device_alias = settings.get("device_alias", "")

    # Build provisioning URL
    provision_url = backend_url.rstrip("/") + "/api/provision.php"

    print(f"Attempting to provision with {provision_url}")
    print(f"Device ID: {device_id}")
    print(f"Device Alias: {device_alias or '(none)'}")

    # Prepare request
    headers = {
        "X-Bootstrap-Secret": bootstrap_secret,
        "Content-Type": "application/json",
    }

    payload = {
        "device_id": device_id,
        "device_alias": device_alias,
    }

    # Retry loop
    for attempt in range(1, MAX_RETRIES + 1):
        try:
            print(f"Provisioning attempt {attempt}/{MAX_RETRIES}...")

            response = requests.post(
                provision_url,
                headers=headers,
                json=payload,
                timeout=30,
            )

            if response.status_code == 200:
                result = response.json()

                if result.get("ok"):
                    new_api_key = result.get("api_key", "")
                    device_name = result.get("device_name", "")
                    was_new = result.get("provisioned", False)

                    if new_api_key:
                        # Save the API key and enable sync
                        settings["remote_api_key"] = new_api_key
                        settings["remote_sync_enabled"] = True
                        settings["remote_sync_url"] = backend_url

                        if device_name and not device_alias:
                            settings["device_alias"] = device_name

                        save_settings(settings)

                        status = "registered" if was_new else "already registered"
                        print(f"SUCCESS: Device {status}!")
                        print(f"API Key: {new_api_key[:8]}...{new_api_key[-4:]}")
                        print(f"Device Name: {device_name}")
                        return True
                    else:
                        print(f"Server returned OK but no API key: {result}")
                        return False
                else:
                    error = result.get("error", "Unknown error")
                    print(f"Provisioning failed: {error}")
                    return False

            elif response.status_code == 401:
                print("Invalid bootstrap secret - check your configuration")
                return False

            elif response.status_code == 403:
                print("Provisioning not enabled on server - configure bootstrap secret in admin")
                return False

            else:
                print(f"Server returned {response.status_code}: {response.text[:200]}")

        except requests.exceptions.ConnectionError as e:
            print(f"Connection error: {e}")
        except requests.exceptions.Timeout:
            print("Request timed out")
        except requests.exceptions.RequestException as e:
            print(f"Request error: {e}")
        except json.JSONDecodeError:
            print(f"Invalid JSON response: {response.text[:200]}")

        if attempt < MAX_RETRIES:
            print(f"Retrying in {RETRY_DELAY} seconds...")
            time.sleep(RETRY_DELAY)

    print(f"Failed to provision after {MAX_RETRIES} attempts")
    return False


def main():
    parser = argparse.ArgumentParser(description="Auto-provision Pi with MOD Projects server")
    parser.add_argument("--force", action="store_true", help="Force re-provisioning even if already done")
    args = parser.parse_args()

    print("=" * 60)
    print("PoolAIssistant Auto-Provisioning")
    print("=" * 60)

    settings = load_settings()

    if provision(settings, force=args.force):
        print("Provisioning complete!")
        return 0
    else:
        print("Provisioning skipped or failed")
        return 1


if __name__ == "__main__":
    sys.exit(main())
