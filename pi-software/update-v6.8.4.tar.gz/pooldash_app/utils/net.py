import socket

def tcp_connect_ok(host: str, port: int, timeout_s: float = 1.0) -> tuple[bool, str | None]:
    try:
        with socket.create_connection((host, port), timeout=timeout_s):
            return True, None
    except Exception as e:
        return False, str(e)
