import sqlite3
from datetime import datetime

def ensure_db(path: str):
    """Ensure the maintenance_logs table exists in the given database.

    This function is idempotent and can be safely called multiple times.
    The table is now stored in pool_readings.sqlite3 alongside readings data,
    enabling automatic backup via existing sync infrastructure.
    """
    conn = sqlite3.connect(path)
    try:
        cur = conn.cursor()
        cur.execute(
            """CREATE TABLE IF NOT EXISTS maintenance_logs (
                   id INTEGER PRIMARY KEY AUTOINCREMENT,
                   timestamp TEXT NOT NULL,
                   pool TEXT NOT NULL,
                   action TEXT NOT NULL,
                   note TEXT
                 )"""
        )
        # Index for efficient queries by pool+action+timestamp
        cur.execute("CREATE INDEX IF NOT EXISTS idx_pool_action_time ON maintenance_logs(pool, action, timestamp)")
        # Index for timestamp-based queries (AI analysis, sync)
        cur.execute("CREATE INDEX IF NOT EXISTS idx_maint_timestamp ON maintenance_logs(timestamp)")
        conn.commit()
    finally:
        conn.close()


def ensure_maintenance_table_in_pool_db(pool_db_path: str):
    """Create maintenance_logs table in pool_readings database.

    This is an alias for ensure_db() but makes the intent clear:
    we're adding the maintenance table to the pool readings DB
    so it gets synced to the server for AI analysis and backup.
    """
    ensure_db(pool_db_path)

def log_action(db_path: str, pool: str, action: str, note: str = ""):
    ensure_db(db_path)
    ts = datetime.now().strftime("%Y-%m-%d %H:%M:%S")
    conn = sqlite3.connect(db_path)
    try:
        conn.execute("INSERT INTO maintenance_logs (timestamp, pool, action, note) VALUES (?,?,?,?)",
                     (ts, pool, action, note.strip() or None))
        conn.commit()
    finally:
        conn.close()

def last_entry(db_path: str, pool: str, action: str) -> tuple[str, str]:
    ensure_db(db_path)
    conn = sqlite3.connect(db_path)
    try:
        cur = conn.cursor()
        cur.execute("""SELECT timestamp, note FROM maintenance_logs
                        WHERE pool=? AND action=? ORDER BY timestamp DESC LIMIT 1""", (pool, action))
        row = cur.fetchone()
        if not row:
            return "—", ""
        ts, note = row
        return ts or "—", note or ""
    finally:
        conn.close()

def fetch_all(db_path: str, pool: str, limit: int = 1000):
    ensure_db(db_path)
    conn = sqlite3.connect(db_path)
    try:
        cur = conn.cursor()
        cur.execute("""SELECT timestamp, pool, action, note
                        FROM maintenance_logs
                        WHERE pool = ? ORDER BY timestamp DESC LIMIT ?""", (pool, limit))
        return cur.fetchall()
    finally:
        conn.close()
