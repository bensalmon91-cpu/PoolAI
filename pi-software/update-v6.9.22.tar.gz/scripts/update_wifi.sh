#!/usr/bin/env bash
set -euo pipefail

# update_wifi.sh <SSID> [PSK]
# Updates NetworkManager (nmcli) or wpa_supplicant as a fallback.
# Run as root (PoolAIssistant calls this via sudo).
# Exit codes: 0=success, 1=connection failed, 2=usage error

SSID="${1:-}"
PSK="${2:-}"
MAX_RETRIES=3
CONNECT_TIMEOUT=20
STABILITY_WAIT=8  # Wait for regulatory domain changes to settle

if [[ -z "$SSID" ]]; then
  echo "Usage: update_wifi.sh <SSID> [PSK]" >&2
  exit 2
fi

# Set regulatory domain to GB to prevent conflicts with APs reporting different regions
# This prevents the "locally_generated disconnect" issue caused by regulatory mismatch
echo "Setting regulatory domain to GB..."
# iw is often in /usr/sbin which may not be in PATH
IW_CMD="${IW_CMD:-/usr/sbin/iw}"
if [[ -x "$IW_CMD" ]]; then
  "$IW_CMD" reg set GB 2>/dev/null || true
elif command -v iw >/dev/null 2>&1; then
  iw reg set GB 2>/dev/null || true
else
  # Fallback: set via cfg80211 kernel interface
  echo "GB" > /sys/module/cfg80211/parameters/ieee80211_regdom 2>/dev/null || true
fi

# Function to verify actual internet/gateway connectivity
verify_connection() {
  local iface="$1"
  local max_wait=15
  local waited=0

  while [[ $waited -lt $max_wait ]]; do
    # Check if interface has an IP
    local ip
    ip=$(ip -4 addr show "$iface" 2>/dev/null | grep -oP '(?<=inet\s)\d+(\.\d+){3}' | head -n1 || true)

    if [[ -n "$ip" ]]; then
      # Get gateway
      local gw
      gw=$(ip route show dev "$iface" 2>/dev/null | grep "default" | awk '{print $3}' | head -n1 || true)

      if [[ -n "$gw" ]]; then
        # Ping gateway to verify actual connectivity
        if ping -c 1 -W 2 "$gw" >/dev/null 2>&1; then
          echo "Connection verified: IP=$ip, Gateway=$gw"
          return 0
        fi
      fi
    fi

    sleep 1
    ((waited++))
  done

  return 1
}

# Stop AP manager if running (it may be holding wlan0)
echo "Stopping AP services..."
systemctl stop poolaissistant_ap_manager.service 2>/dev/null || true
systemctl stop hostapd.service 2>/dev/null || true
systemctl stop dnsmasq.service 2>/dev/null || true

# Wait for interface to be released
sleep 2

# Prefer NetworkManager if present
if command -v nmcli >/dev/null 2>&1; then
  IFACE="wlan0"
  CONN_DIR="/etc/NetworkManager/system-connections"
  # Sanitize SSID for filename (replace spaces and special chars)
  CONN_NAME="$(echo "$SSID" | tr ' ' '_' | tr -cd '[:alnum:]_-')"
  CONN_FILE="${CONN_DIR}/${CONN_NAME}.nmconnection"

  # Generate a UUID for the connection
  CONN_UUID="$(cat /proc/sys/kernel/random/uuid 2>/dev/null || echo "$(date +%s)-$$-wifi")"

  # Ensure WiFi radio is on
  nmcli radio wifi on 2>/dev/null || true
  sleep 1

  # Disconnect current connection first
  nmcli device disconnect "$IFACE" 2>/dev/null || true
  sleep 1

  # Delete any existing connections with this SSID to start fresh
  for existing in $(nmcli -t -f NAME,TYPE con show | grep ":wifi$" | cut -d: -f1); do
    # Check if this connection is for our SSID
    existing_ssid="$(nmcli -t -f 802-11-wireless.ssid con show "$existing" 2>/dev/null | cut -d: -f2 || true)"
    if [[ "$existing_ssid" == "$SSID" ]]; then
      echo "Deleting existing connection: $existing"
      nmcli con delete "$existing" 2>/dev/null || true
    fi
  done

  # Also delete netplan-generated connections that might conflict
  for conn in $(nmcli -t -f NAME con show | grep "^netplan-wlan0" || true); do
    nmcli con delete "$conn" 2>/dev/null || true
  done

  # Remove any existing connection file for this network
  rm -f "$CONN_FILE" 2>/dev/null || true

  # Rescan for networks
  echo "Scanning for networks..."
  nmcli device wifi rescan 2>/dev/null || true
  sleep 3

  # Create connection file directly (more reliable than nmcli device wifi connect)
  # This avoids the "key-mgmt: property is missing" bug
  echo "Creating connection file for '$SSID'..."

  if [[ -n "$PSK" ]]; then
    # WPA/WPA2 secured network
    cat > "$CONN_FILE" << NMEOF
[connection]
id=${SSID}
uuid=${CONN_UUID}
type=wifi
interface-name=${IFACE}

[wifi]
mode=infrastructure
ssid=${SSID}

[wifi-security]
auth-alg=open
key-mgmt=wpa-psk
psk=${PSK}

[ipv4]
method=auto

[ipv6]
addr-gen-mode=default
method=auto

[proxy]
NMEOF
  else
    # Open network (no password)
    cat > "$CONN_FILE" << NMEOF
[connection]
id=${SSID}
uuid=${CONN_UUID}
type=wifi
interface-name=${IFACE}

[wifi]
mode=infrastructure
ssid=${SSID}

[wifi-security]
key-mgmt=none

[ipv4]
method=auto

[ipv6]
addr-gen-mode=default
method=auto

[proxy]
NMEOF
  fi

  # Set correct permissions (required by NetworkManager)
  chmod 600 "$CONN_FILE"
  chown root:root "$CONN_FILE"

  # Reload connections
  echo "Reloading NetworkManager connections..."
  nmcli con reload
  sleep 1

  # Try to connect with retries
  connected=false
  for attempt in $(seq 1 $MAX_RETRIES); do
    echo "Connection attempt $attempt of $MAX_RETRIES..."

    # Activate the connection using nmcli con up (more reliable)
    if nmcli con up "$SSID" 2>&1; then
      echo "nmcli con up succeeded"
    else
      echo "nmcli con up failed, retrying..."
      sleep 2
      continue
    fi

    # Wait for regulatory domain changes to settle (can cause disconnect ~4s after connect)
    echo "Waiting for connection to stabilize..."
    sleep $STABILITY_WAIT

    # Verify actual connectivity
    if verify_connection "$IFACE"; then
      # Double-check after brief pause (regulatory domain changes can be delayed)
      sleep 2
      if verify_connection "$IFACE"; then
        connected=true
        break
      fi
    fi

    echo "Connection verification failed, retrying..."
    nmcli device disconnect "$IFACE" 2>/dev/null || true
    sleep 2
  done

  if $connected; then
    IP=$(ip -4 addr show "$IFACE" 2>/dev/null | grep -oP '(?<=inet\s)\d+(\.\d+){3}' | head -n1 || true)
    echo "SUCCESS: Connected to '$SSID'"
    echo "IP address: $IP"

    # Restart AP manager (it will check if WiFi is connected and stay off)
    systemctl start poolaissistant_ap_manager.service 2>/dev/null || true
    exit 0
  else
    echo "FAILED: Could not connect to '$SSID' after $MAX_RETRIES attempts"
    echo "Restarting AP manager for recovery access..."
    systemctl start poolaissistant_ap_manager.service 2>/dev/null || true
    exit 1
  fi
fi

# Fallback: wpa_supplicant (common on Raspberry Pi OS Lite without NM)
WPA_CONF="/etc/wpa_supplicant/wpa_supplicant.conf"
if [[ -f "$WPA_CONF" ]]; then
  echo "Using wpa_supplicant fallback..."

  # Backup current config
  cp "$WPA_CONF" "${WPA_CONF}.bak"

  # remove existing network blocks for same ssid
  tmp="$(mktemp)"
  awk -v ssid="$SSID" '
    BEGIN{inblock=0; skip=0}
    /network=\{/ {inblock=1; block=""; skip=0}
    {
      if(inblock){ block=block $0 "\n" }
    }
    inblock && /ssid="/ {
      if($0 ~ "ssid=\""ssid"\""){ skip=1 }
    }
    inblock && /\}/ {
      inblock=0
      if(!skip){ printf "%s", block }
    }
    !inblock && !/network=\{/ { print }
  ' "$WPA_CONF" > "$tmp" || cp "$WPA_CONF" "$tmp"

  if [[ -n "$PSK" ]]; then
    # Escape special characters in PSK for wpa_passphrase
    wpa_passphrase "$SSID" "$PSK" >> "$tmp" 2>/dev/null || {
      echo "ERROR: wpa_passphrase failed - password may contain special characters"
      rm -f "$tmp"
      exit 1
    }
  else
    # Open network
    cat >> "$tmp" <<EOF
network={
    ssid="$SSID"
    key_mgmt=NONE
}
EOF
  fi

  install -m 600 "$tmp" "$WPA_CONF"
  rm -f "$tmp"

  # restart service
  systemctl restart wpa_supplicant.service || true
  sleep 3

  # Verify connection with wpa_supplicant
  IFACE="wlan0"
  if verify_connection "$IFACE"; then
    echo "SUCCESS: Connected to '$SSID' via wpa_supplicant"
    systemctl start poolaissistant_ap_manager.service 2>/dev/null || true
    exit 0
  else
    echo "FAILED: Could not connect to '$SSID'"
    echo "Restoring previous config and restarting AP..."
    cp "${WPA_CONF}.bak" "$WPA_CONF"
    systemctl restart wpa_supplicant.service || true
    systemctl start poolaissistant_ap_manager.service 2>/dev/null || true
    exit 1
  fi
fi

echo "No supported Wi-Fi manager found (nmcli or wpa_supplicant.conf)." >&2
systemctl start poolaissistant_ap_manager.service 2>/dev/null || true
exit 1
