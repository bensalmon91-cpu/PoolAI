"""
Alarm code to human-readable description mapping
Maps technical alarm codes to user-friendly messages with severity and actions
"""

ALARM_DESCRIPTIONS = {
    # pH Controller Alarms
    "Status_Mode_Controller2_pH:b0": {
        "name": "pH Controller in Manual Mode",
        "severity": "warning",
        "description": "pH dosing controller is set to manual mode - automatic dosing disabled",
        "action": "Check if manual control is intended. Switch to auto mode if needed.",
    },
    "Status_Mode_Controller2_pH:b1": {
        "name": "pH Controller Error",
        "severity": "critical",
        "description": "pH controller has detected an error condition",
        "action": "Check pH probe connection and calibration. Review controller display.",
    },
    "Status_Mode_Controller2_pH:b2": {
        "name": "pH Probe Fault",
        "severity": "critical",
        "description": "pH probe is not responding or giving invalid readings",
        "action": "Clean or replace pH probe. Check wiring connections.",
    },
    "Status_Mode_Controller2_pH:b3": {
        "name": "pH Dosing Pump Fault",
        "severity": "critical",
        "description": "pH dosing pump has stopped or is not operating correctly",
        "action": "Check pump operation, tubing, and chemical supply.",
    },

    # Chlorine Controller Alarms
    "Status_Mode_Controller1_Chlorine:b0": {
        "name": "Chlorine Controller in Manual Mode",
        "severity": "warning",
        "description": "Chlorine dosing controller is set to manual mode - automatic dosing disabled",
        "action": "Check if manual control is intended. Switch to auto mode if needed.",
    },
    "Status_Mode_Controller1_Chlorine:b1": {
        "name": "Chlorine Controller Error",
        "severity": "critical",
        "description": "Chlorine controller has detected an error condition",
        "action": "Check chlorine probe connection and calibration. Review controller display.",
    },
    "Status_Mode_Controller1_Chlorine:b2": {
        "name": "Chlorine Probe Fault",
        "severity": "critical",
        "description": "Chlorine probe is not responding or giving invalid readings",
        "action": "Clean or replace chlorine probe. Check wiring connections.",
    },
    "Status_Mode_Controller1_Chlorine:b3": {
        "name": "Chlorine Dosing Pump Fault",
        "severity": "critical",
        "description": "Chlorine dosing pump has stopped or is not operating correctly",
        "action": "Check pump operation, tubing, and chemical supply.",
    },
    "Status_Mode_Controller1_Chlorine:b4": {
        "name": "Low Chlorine Chemical",
        "severity": "warning",
        "description": "Chlorine chemical level is low",
        "action": "Refill chlorine chemical tank.",
    },

    # ORP Controller Alarms
    "Status_Mode_Controller3_ORP:b0": {
        "name": "ORP Controller in Manual Mode",
        "severity": "warning",
        "description": "ORP controller is set to manual mode",
        "action": "Check if manual control is intended. Switch to auto mode if needed.",
    },
    "Status_Mode_Controller3_ORP:b1": {
        "name": "ORP Controller Error",
        "severity": "critical",
        "description": "ORP controller has detected an error condition",
        "action": "Check ORP probe connection and calibration. Review controller display.",
    },
    "Status_Mode_Controller3_ORP:b2": {
        "name": "ORP Probe Fault",
        "severity": "critical",
        "description": "ORP (Redox) probe is not responding or giving invalid readings",
        "action": "Clean or replace ORP probe. Check wiring connections.",
    },
    "Status_Mode_Controller3_ORP:b3": {
        "name": "ORP Dosing Pump Fault",
        "severity": "critical",
        "description": "ORP dosing pump has stopped or is not operating correctly",
        "action": "Check pump operation, tubing, and chemical supply.",
    },

    # Channel 4 Controller Alarms
    "Status_Mode_Controller4_Ch4:b0": {
        "name": "Channel 4 in Manual Mode",
        "severity": "warning",
        "description": "Channel 4 controller is set to manual mode - automatic control disabled",
        "action": "Check if manual control is intended. Switch to auto mode if needed.",
    },
    "Status_Mode_Controller4_Ch4:b1": {
        "name": "Channel 4 Controller Error",
        "severity": "critical",
        "description": "Channel 4 controller has detected an error condition",
        "action": "Check probe connection and calibration. Review controller display.",
    },
    "Status_Mode_Controller4_Ch4:b2": {
        "name": "Channel 4 Probe Fault",
        "severity": "critical",
        "description": "Channel 4 probe is not responding or giving invalid readings",
        "action": "Clean or replace probe. Check wiring connections.",
    },
    "Status_Mode_Controller4_Ch4:b3": {
        "name": "Channel 4 Dosing Pump Fault",
        "severity": "critical",
        "description": "Channel 4 dosing pump has stopped or is not operating correctly",
        "action": "Check pump operation, tubing, and chemical supply.",
    },

    # Relay/Output Alarms
    "Status_RelayOutputs_K1_8:b0": {
        "name": "Relay K1 Activated",
        "severity": "info",
        "description": "Output relay K1 is active (pump or valve operation)",
        "action": "Normal operation - no action needed.",
    },
    "Status_RelayOutputs_K1_8:b1": {
        "name": "Relay K2 Activated",
        "severity": "info",
        "description": "Output relay K2 is active (pump or valve operation)",
        "action": "Normal operation - no action needed.",
    },
    "Status_RelayOutputs_K1_8:b2": {
        "name": "Relay K3 Activated",
        "severity": "info",
        "description": "Output relay K3 is active (pump or valve operation)",
        "action": "Normal operation - no action needed.",
    },
    "Status_RelayOutputs_K1_8:b3": {
        "name": "Relay K4 Activated",
        "severity": "info",
        "description": "Output relay K4 is active (pump or valve operation)",
        "action": "Normal operation - no action needed.",
    },

    # Limit/Contact Alarms
    "Status_LimitContactStates:b0": {
        "name": "Limit Contact 1 Triggered",
        "severity": "warning",
        "description": "External limit contact or interlock has been triggered",
        "action": "Check connected equipment and safety interlocks.",
    },
    "Status_LimitContactStates:b1": {
        "name": "Flow Switch Open",
        "severity": "critical",
        "description": "No water flow detected - pump may not be running",
        "action": "Check pump operation and flow switch. Dosing stopped for safety.",
    },
    "Status_LimitContactStates:b2": {
        "name": "High Level Alarm",
        "severity": "critical",
        "description": "Chemical tank high level alarm activated",
        "action": "Check chemical tank levels and sensors.",
    },
    "Status_LimitContactStates:b3": {
        "name": "Low Level Alarm",
        "severity": "warning",
        "description": "Chemical tank low level alarm activated",
        "action": "Refill chemical tank.",
    },

    # ===========================================
    # Error Code Registers (all bits are alarms)
    # ===========================================

    # Analog Hardware Errors
    "AnalogHardwareError:b0": {
        "name": "Analog Input 1 Hardware Error",
        "severity": "critical",
        "description": "Hardware fault detected on analog input channel 1",
        "action": "Check sensor wiring and connections. May require service.",
    },
    "AnalogHardwareError:b1": {
        "name": "Analog Input 2 Hardware Error",
        "severity": "critical",
        "description": "Hardware fault detected on analog input channel 2",
        "action": "Check sensor wiring and connections. May require service.",
    },
    "AnalogHardwareError:b2": {
        "name": "Analog Input 3 Hardware Error",
        "severity": "critical",
        "description": "Hardware fault detected on analog input channel 3",
        "action": "Check sensor wiring and connections. May require service.",
    },
    "AnalogHardwareError:b3": {
        "name": "Analog Input 4 Hardware Error",
        "severity": "critical",
        "description": "Hardware fault detected on analog input channel 4",
        "action": "Check sensor wiring and connections. May require service.",
    },

    # Calibration Errors
    "CalibrationError:b0": {
        "name": "Channel 1 Calibration Error",
        "severity": "warning",
        "description": "Calibration required or invalid on channel 1 (Chlorine)",
        "action": "Recalibrate the chlorine sensor using fresh calibration solution.",
    },
    "CalibrationError:b1": {
        "name": "Channel 2 Calibration Error",
        "severity": "warning",
        "description": "Calibration required or invalid on channel 2 (pH)",
        "action": "Recalibrate the pH sensor using fresh buffer solutions.",
    },
    "CalibrationError:b2": {
        "name": "Channel 3 Calibration Error",
        "severity": "warning",
        "description": "Calibration required or invalid on channel 3 (ORP)",
        "action": "Recalibrate the ORP sensor using fresh calibration solution.",
    },
    "CalibrationError:b3": {
        "name": "Channel 4 Calibration Error",
        "severity": "warning",
        "description": "Calibration required or invalid on channel 4",
        "action": "Recalibrate the sensor using appropriate calibration solution.",
    },

    # Cell/Electrode Errors
    "CellError:b0": {
        "name": "Chlorine Cell Error",
        "severity": "critical",
        "description": "Chlorine measurement cell fault detected",
        "action": "Check chlorine sensor cell. Clean or replace if necessary.",
    },
    "CellError:b1": {
        "name": "pH Cell Error",
        "severity": "critical",
        "description": "pH measurement cell fault detected",
        "action": "Check pH sensor. Clean or replace electrode if necessary.",
    },
    "CellError:b2": {
        "name": "ORP Cell Error",
        "severity": "critical",
        "description": "ORP measurement cell fault detected",
        "action": "Check ORP sensor. Clean or replace electrode if necessary.",
    },
    "CellError:b3": {
        "name": "Channel 4 Cell Error",
        "severity": "critical",
        "description": "Channel 4 measurement cell fault detected",
        "action": "Check sensor. Clean or replace if necessary.",
    },

    # Temperature Errors
    "TemperatureError:b0": {
        "name": "Temperature Sensor Error",
        "severity": "warning",
        "description": "Temperature sensor fault or out of range",
        "action": "Check temperature sensor wiring and placement.",
    },
    "TemperatureError:b1": {
        "name": "Temperature Out of Range",
        "severity": "warning",
        "description": "Water temperature outside acceptable operating range",
        "action": "Verify water temperature is within normal pool operating range.",
    },

    # Setpoint/Limit Errors
    "SetpointError:b0": {
        "name": "Chlorine Setpoint Error",
        "severity": "warning",
        "description": "Chlorine setpoint configuration error",
        "action": "Review and correct chlorine setpoint settings.",
    },
    "SetpointError:b1": {
        "name": "pH Setpoint Error",
        "severity": "warning",
        "description": "pH setpoint configuration error",
        "action": "Review and correct pH setpoint settings.",
    },
    "SetpointError:b2": {
        "name": "ORP Setpoint Error",
        "severity": "warning",
        "description": "ORP setpoint configuration error",
        "action": "Review and correct ORP setpoint settings.",
    },

    "LimitValueError:b0": {
        "name": "Chlorine Limit Exceeded",
        "severity": "warning",
        "description": "Chlorine level outside configured alarm limits",
        "action": "Check dosing system and adjust if necessary.",
    },
    "LimitValueError:b1": {
        "name": "pH Limit Exceeded",
        "severity": "warning",
        "description": "pH level outside configured alarm limits",
        "action": "Check dosing system and adjust if necessary.",
    },
    "LimitValueError:b2": {
        "name": "ORP Limit Exceeded",
        "severity": "warning",
        "description": "ORP level outside configured alarm limits",
        "action": "Check dosing system and adjust if necessary.",
    },

    # Dosing Errors
    "DosageAnalogError:b0": {
        "name": "Chlorine Dosing Output Error",
        "severity": "critical",
        "description": "Chlorine dosing analog output fault",
        "action": "Check dosing pump connections and 4-20mA output.",
    },
    "DosageAnalogError:b1": {
        "name": "pH Dosing Output Error",
        "severity": "critical",
        "description": "pH dosing analog output fault",
        "action": "Check dosing pump connections and 4-20mA output.",
    },
    "DosageAnalogError:b2": {
        "name": "ORP Dosing Output Error",
        "severity": "critical",
        "description": "ORP dosing analog output fault",
        "action": "Check dosing pump connections and 4-20mA output.",
    },

    # mA Output Load Errors
    "mAOutput1LoadError:b0": {
        "name": "mA Output 1 Load Error",
        "severity": "critical",
        "description": "4-20mA output 1 has no load or short circuit",
        "action": "Check wiring to dosing pump or actuator on output 1.",
    },
    "mAOutput2LoadError:b0": {
        "name": "mA Output 2 Load Error",
        "severity": "critical",
        "description": "4-20mA output 2 has no load or short circuit",
        "action": "Check wiring to dosing pump or actuator on output 2.",
    },
    "mAOutput3LoadError:b0": {
        "name": "mA Output 3 Load Error",
        "severity": "critical",
        "description": "4-20mA output 3 has no load or short circuit",
        "action": "Check wiring to dosing pump or actuator on output 3.",
    },
    "mAOutput4LoadError:b0": {
        "name": "mA Output 4 Load Error",
        "severity": "critical",
        "description": "4-20mA output 4 has no load or short circuit",
        "action": "Check wiring to dosing pump or actuator on output 4.",
    },

    # Data Storage Errors
    "DataStorageError_SD_EEprom:b0": {
        "name": "SD Card Error",
        "severity": "warning",
        "description": "SD card read/write error or card missing",
        "action": "Check SD card is inserted correctly. Replace if faulty.",
    },
    "DataStorageError_SD_EEprom:b1": {
        "name": "EEPROM Error",
        "severity": "critical",
        "description": "Internal EEPROM memory error",
        "action": "Controller may need factory reset or service.",
    },

    # AutoTune Errors
    "AutoTuneError:b0": {
        "name": "Chlorine AutoTune Error",
        "severity": "warning",
        "description": "Chlorine controller auto-tuning failed",
        "action": "Check system stability and retry auto-tune procedure.",
    },
    "AutoTuneError:b1": {
        "name": "pH AutoTune Error",
        "severity": "warning",
        "description": "pH controller auto-tuning failed",
        "action": "Check system stability and retry auto-tune procedure.",
    },

    # Factory Calibration Error
    "FactoryCalibrationError:b0": {
        "name": "Factory Calibration Error",
        "severity": "critical",
        "description": "Factory calibration data corrupted or missing",
        "action": "Controller requires factory service.",
    },

    # Flocculation Error
    "FlocculationError:b0": {
        "name": "Flocculation System Error",
        "severity": "warning",
        "description": "Flocculation dosing system fault",
        "action": "Check flocculant pump and chemical supply.",
    },

    # Peak Chlorination Errors
    "PeakChlorinationError:b0": {
        "name": "Peak Chlorination Error",
        "severity": "warning",
        "description": "Peak chlorination cycle fault",
        "action": "Check chlorine supply and dosing system capacity.",
    },
    "PeakChlorinationError_Cl2pp:b0": {
        "name": "Peak Chlorination Cl2pp Error",
        "severity": "warning",
        "description": "Peak chlorination parts-per-million calculation error",
        "action": "Check chlorine sensor calibration and readings.",
    },

    # Combined Chlorine Error
    "CombinedChlorineError:b0": {
        "name": "Combined Chlorine High",
        "severity": "warning",
        "description": "Combined chlorine level too high - indicates chloramine formation",
        "action": "Consider superchlorination or partial water replacement.",
    },

    # Channel-specific Error Codes
    "ErrorCode_Chlorine:b0": {
        "name": "Chlorine Error Code Active",
        "severity": "critical",
        "description": "Chlorine channel has an active error condition",
        "action": "Check chlorine sensor and controller. Review error code on display.",
    },
    "ErrorCode_pH:b0": {
        "name": "pH Error Code Active",
        "severity": "critical",
        "description": "pH channel has an active error condition",
        "action": "Check pH sensor and controller. Review error code on display.",
    },
    "ErrorCode_ORP:b0": {
        "name": "ORP Error Code Active",
        "severity": "critical",
        "description": "ORP channel has an active error condition",
        "action": "Check ORP sensor and controller. Review error code on display.",
    },
    "ErrorCode_Temperature:b0": {
        "name": "Temperature Error Code Active",
        "severity": "warning",
        "description": "Temperature channel has an active error condition",
        "action": "Check temperature sensor. Review error code on display.",
    },
    "ErrorCode_TotalChlorine:b0": {
        "name": "Total Chlorine Error Code Active",
        "severity": "critical",
        "description": "Total chlorine channel has an active error condition",
        "action": "Check total chlorine sensor. Review error code on display.",
    },
}


SEVERITY_COLORS = {
    "info": "#0b5bd3",      # Blue
    "warning": "#ff9800",   # Orange
    "critical": "#b00020",  # Red
}


SEVERITY_ICONS = {
    "info": "ℹ️",
    "warning": "⚠️",
    "critical": "🚨",
}


# Error register labels - all bits are alarms for these
ERROR_REGISTERS = {
    "AnalogHardwareError": ("Analog Hardware Error", "critical"),
    "AutoTuneError": ("Auto-Tune Error", "warning"),
    "CalibrationError": ("Calibration Error", "warning"),
    "CellError": ("Measurement Cell Error", "critical"),
    "CombinedChlorineError": ("Combined Chlorine Error", "warning"),
    "DataStorageError_SD_EEprom": ("Data Storage Error", "warning"),
    "DosageAnalogError": ("Dosing Output Error", "critical"),
    "FactoryCalibrationError": ("Factory Calibration Error", "critical"),
    "FlocculationError": ("Flocculation Error", "warning"),
    "LimitValueError": ("Limit Value Error", "warning"),
    "PeakChlorinationError": ("Peak Chlorination Error", "warning"),
    "PeakChlorinationError_Cl2pp": ("Peak Chlorination Error", "warning"),
    "SetpointError": ("Setpoint Error", "warning"),
    "TemperatureError": ("Temperature Error", "warning"),
    "mAOutput1LoadError": ("mA Output 1 Load Error", "critical"),
    "mAOutput2LoadError": ("mA Output 2 Load Error", "critical"),
    "mAOutput3LoadError": ("mA Output 3 Load Error", "critical"),
    "mAOutput4LoadError": ("mA Output 4 Load Error", "critical"),
    "ErrorCode_Chlorine": ("Chlorine Error", "critical"),
    "ErrorCode_ORP": ("ORP Error", "critical"),
    "ErrorCode_Temperature": ("Temperature Error", "warning"),
    "ErrorCode_TotalChlorine": ("Total Chlorine Error", "critical"),
    "ErrorCode_pH": ("pH Error", "critical"),
}


def get_alarm_info(label):
    """
    Get human-readable alarm information

    Args:
        label: Technical alarm label (e.g., "Status_Mode_Controller2_pH:b0")

    Returns:
        dict with name, severity, description, action, color, icon
    """
    if label in ALARM_DESCRIPTIONS:
        info = ALARM_DESCRIPTIONS[label].copy()
        severity = info.get("severity", "info")
        info["color"] = SEVERITY_COLORS.get(severity, "#888")
        info["icon"] = SEVERITY_ICONS.get(severity, "•")
        return info

    # Smart fallback for error registers with any bit number
    if ":" in label:
        source_label, bit_name = label.rsplit(":", 1)
        if source_label in ERROR_REGISTERS:
            name, severity = ERROR_REGISTERS[source_label]
            bit_num = bit_name.replace("b", "") if bit_name.startswith("b") else bit_name
            return {
                "name": f"{name} (Bit {bit_num})",
                "severity": severity,
                "description": f"Error condition detected in {source_label}",
                "action": "Check controller display for specific error code.",
                "color": SEVERITY_COLORS.get(severity, "#888"),
                "icon": SEVERITY_ICONS.get(severity, "•"),
            }

    # Generic fallback for unknown alarms
    return {
        "name": label,  # Use technical name
        "severity": "warning",  # Default to warning for unknown alarms
        "description": "Alarm condition detected",
        "action": "Check controller display for details.",
        "color": SEVERITY_COLORS.get("warning", "#ff9800"),
        "icon": SEVERITY_ICONS.get("warning", "⚠️"),
    }


def clean_system_name(raw_name):
    """Clean up system name by removing null characters and extra data"""
    if not raw_name:
        return ""

    # Remove null characters and split by common delimiters
    cleaned = raw_name.replace('\x00', ' ').strip()

    # Often the format is: "Pool name <nulls> version <nulls> date"
    # Take only the first meaningful part
    parts = [p.strip() for p in cleaned.split() if p.strip()]
    if parts:
        # Return first non-version part (version usually starts with 'v')
        for part in parts:
            if not part.startswith('v') and not part.replace('.', '').replace('-', '').isdigit():
                return part
        return parts[0]

    return cleaned
